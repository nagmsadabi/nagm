<?php

require ('sysfrm/boot.php');
App::_run();
