<?php
Class App{
    public static function _run(){
        return true;
    }

}